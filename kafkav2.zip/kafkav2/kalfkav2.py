import csv
import re
from datetime import datetime

def parse_file_to_csv(input_file, output_file):
    rows = []
    current_section = None
    create_time = None
    timestamp_counter = 0

    with open(input_file, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()

            # Detect section headers (e.g., "360-apb-transactions-v2")
            if line.startswith("360"):
                current_section = line  # Store transaction type
                timestamp_counter = 0  # Reset counter for timestamps

            # Detect CreateTime (e.g., "CreateTime: 1733583080147")
            elif line.startswith("CreateTime:"):
                create_time = int(line.split(":")[1].strip())

            # Extract key-value pairs manually
            else:
                # Match key-value pairs like `"key": "value"` or `"key": value`
                matches = re.findall(r'"?([\w@]+)"?\s*:\s*"?([^",{}\[\]]+)"?', line)

                for key, value in matches:
                    timestamp_counter += 1
                    rows.append([current_section, create_time + timestamp_counter, key, value])

    # Write to CSV
    with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile, delimiter='\t')  # Tab-separated
        writer.writerow(["transaction_type", "CreateTime", "key", "value"])  # Header row
        writer.writerows(rows)

    print(f"CSV file successfully written to {output_file}")

# Example usage
input_file_path = "code.txt"  # Replace with your actual file path
output_file_path = "parsed_transactions.csv"  # Output CSV file
parse_file_to_csv(input_file_path, output_file_path)
