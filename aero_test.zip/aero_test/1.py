import json
import pandas as pd
import os

# Ensure script runs in the correct directory
print("Current working directory:", os.getcwd())

# Read input JSON file
json_file_path = r"C:\Users\Mankaran\Downloads\aero_test\test.json"
output_file_path = r"C:\Users\Mankaran\Downloads\aero_test\output.xlsx"

with open(json_file_path, "r") as file:
    aerospike_logs = json.load(file)

# Preparing data for DataFrame
rows = []

for aerospike_log in aerospike_logs:
    set_name = aerospike_log["Set Name"]
    key_value = tuple(aerospike_log["key"])  # Ensure key is stored as a tuple
    json_data = aerospike_log["JSON Data"]
    
    for k, v in json_data.items():
        rows.append([set_name, key_value, k, json.dumps(v)])  # Ensure JSON values are properly formatted

# Creating DataFrame
df = pd.DataFrame(rows, columns=["Set", "Key", "Field", "Value"])

# Writing to Excel
df.to_excel(output_file_path, index=False)

print(f"Excel file saved at: {output_file_path}")
